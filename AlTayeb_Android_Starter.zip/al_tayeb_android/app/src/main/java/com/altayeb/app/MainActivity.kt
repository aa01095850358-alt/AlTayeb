package com.altayeb.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Room(val name: String, val people: Int, val host: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlTayebApp() }
    }
}

@Composable
fun AlTayebApp() {
    var selectedRoom by remember { mutableStateOf<Room?>(null) }
    val rooms = listOf(
        Room("سهرة الطيب", 28, "أحمد"),
        Room("لمة الأصدقاء", 16, "محمد"),
        Room("مجلس الرواشدية", 41, "خالد")
    )

    MaterialTheme {
        if (selectedRoom == null) {
            HomeScreen(rooms) { selectedRoom = it }
        } else {
            RoomScreen(selectedRoom!!) { selectedRoom = null }
        }
    }
}

@Composable
fun HomeScreen(rooms: List<Room>, onOpen: (Room) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("الطيب", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {}) { Text("+", fontSize = 26.sp) }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("الغرف الصوتية", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(rooms) { room ->
                    Card(onClick = { onOpen(room) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(room.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text("المضيف: ${room.host}")
                            Text("👥 ${room.people} مستمع")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoomScreen(room: Room, onLeave: () -> Unit) {
    var muted by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(room.name) },
                navigationIcon = { TextButton(onClick = onLeave) { Text("خروج") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(25.dp))
            Text("🎙️", fontSize = 64.sp)
            Text("الغرفة الصوتية", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("عدد الموجودين: ${room.people}")
            Spacer(Modifier.weight(1f))
            Button(onClick = { muted = !muted }, modifier = Modifier.fillMaxWidth()) {
                Text(if (muted) "تشغيل الميكروفون" else "كتم الميكروفون")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) {
                Text("مغادرة الغرفة")
            }
        }
    }
}
